JANSEVA Android Demo
====================

Package / application ID: com.janseva.publichelping

This is a small offline Android prototype for a college project demonstration.
Included screens:
- Home dashboard
- Submit a civic complaint (department, location, description)
- View complaints created during the current app session
- About / demo limitations

Important:
- This is NOT the complete JANSEVA production system.
- It does not connect to FastAPI, SQLite, government departments, AI, GPS,
  photo upload, login, or push notifications.
- Demo complaints are held in memory and disappear when the app process closes.
- Use dummy information only.

Build the APK on Windows:
1. Install Android Studio and the Android SDK (API 35 or a compatible SDK).
2. Extract this ZIP.
3. Open the JANSEVA_Android_Demo folder in Android Studio.
4. Allow Gradle sync to finish. Internet may be needed the first time to download
   Android Gradle Plugin and Gradle.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build succeeds, click "locate". The APK should be under:
   app/build/outputs/apk/debug/app-debug.apk

For a release APK:
Build > Generate Signed Bundle / APK > APK.
For a college demo, a debug APK is sufficient for local testing.

Requirements:
- Android Studio
- JDK 17 (Android Studio bundles a compatible JDK)
- Android SDK Platform 35
